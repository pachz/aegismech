<!DOCTYPE html>

<html lang="en-US"><!--<![endif]-->
<head>
    <meta charset="utf-8">

    <title>AEGIS Mechanical Corporation</title>

    <!-- Define a viewport to mobile devices to use - telling the browser to assume that the page is as wide as the device (width=device-width) and setting the initial page zoom level to be 1 (initial-scale=1.0) -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Include google fonts stylesheet -->
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900,300,100,200' rel='stylesheet'
          type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,800,700,600,300'
          rel='stylesheet' type='text/css'>

    <!-- Include the bootstrap stylesheet -->
    <link href="css/bootstrap.css" rel="stylesheet" media="all">

    <!-- Include the Font Awesome stylesheet -->
    <link href="css/font-awesome.css" rel="stylesheet" media="all">

    <!-- Include the Flexslider stylesheet -->
    <link href="js/flexslider/flexslider.css" rel="stylesheet" media="all">

    <!-- Include the Owl Carousel stylesheet -->
    <link href="js/owl-carousel/owl.carousel.css" rel="stylesheet" media="all">

    <!-- Include the Owl Theme stylesheet -->
    <link href="js/owl-carousel/owl.theme.css" rel="stylesheet" media="all">

    <!-- Include the Adipoli stylesheet -->
    <link href="js/adipoli/adipoli.css" rel="stylesheet" media="all">

    <!-- Include the Swipebox stylesheet -->
    <link href="js/swipebox/swipebox.css" rel="stylesheet" media="all">


    <!-- Include the Main Menu stylesheet -->
    <link href="js/mean-menu/meanmenu.min.css" rel="stylesheet" media="all">

    <!-- Include the site main stylesheet -->
    <link href="css/main.css" rel="stylesheet" media="all">

    <!-- Include the site animation stylesheet -->
    <link href="css/animate.min.css" rel="stylesheet" media="all">

    <!-- Include the site responsive tables stylesheet -->
    <link href="css/responsive-tables.css" rel="stylesheet" media="all">

    <!-- Jqurey  -->
    <script src="js/jquery.min.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->

</head>
<body>

<div class="preloader">
    <div class="preloaderimg"></div>
</div>

<div id="top"></div>
<!--top main menu-->
<!-- Header Wrapper -->
<div class="header-wrapper variant-four sticky-header">

    <!-- Start Header -->
    <header class="header container custom-container-header" role="banner">

        <div class="row">
            <div class="col-md-5 custom-col-var4">
                <!-- Start of Main Navigation    -->
                <div class="main-menu-wrapper">
                    <nav id="nav" class="parallax-menu main-menu clearfix" role="navigation">
                        <ul class="clearfix">
                            <!--<li><a href="#top">home</a></li>-->
                            <li><a href="#about">about</a></li>
                            <li><a href="#projects">projects</a></li>
                            <li><a href="#work">portfolio</a></li>
                            <li><a href="#careers">careers</a></li>

                            <li><a href="#contact">contact</a></li>
                        </ul>
                    </nav>
                </div>
                <!-- End of Main Navigation  -->
            </div>
            <div class="col-md-2 custom-col-var4 text-center">

                <!-- Logo -->
                <div class="logo-wrapper">
                    <div id="logo">

                        <a title="Aegis Mechanical" href="#top">
                            <img id="logo-image" src="images/logo.png" alt="Mixer">
                        </a>

                    </div>

                </div>
            </div>
            <div class="col-md-5 custom-col-contact">
                <div class="contact-card">
                    <button type="button" class="close visible-xs" aria-hidden="true"><i class="fa fa-remove"></i>
                    </button>
                    <div class="wrapper-contact-options">
                        <div class="contact-options">

        <span class="email">
            <a href="mailto:info@aegismechanical.com">info@aegismechanical.com</a>
        </span>

                            <span class="phone-number">443 436 6001</span>

                        </div>

                        <!--<ul class="social_networks clearfix">

                            <li class="facebook">
                                <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
                            </li>

                            <li class="twitter">
                                <a href="#" target="_blank"><i class="fa fa-twitter"></i></a>
                            </li>


                            <li class="rss">
                                <a target="_blank" href="# "> <i class="fa fa-rss"></i></a>
                            </li>

                            <li class="gplus">
                                <a href="# " target="_blank"><i class="fa fa-google-plus"></i></a>
                            </li>

                        </ul>-->
                    </div>

                </div>


            </div>
        </div>

    </header>
    <!-- End Header -->

</div>
<!--top main menu ends-->

<!--home slider-->
<div class="home-slider  container-fluid home-slider-4">
    <div class="inner-wrapper">
        <div class="flexslider variant-three">
            <ul class="slides">

                <li>
                    <div class="container custom-container-slide">
                        <div class="slide-description">
                            <p style='font-weight: bold; font-size: 26px;'>~~Website is Under Construction~~</p>
                            <h2 class="title">AEGIS MECHANICAL CORPORATION</h2>
   <p style='font-weight: bold; font-size: 22px;'>Mechanical Construction Solutions</p>
                        </div>
                    </div>
                </li>

                <li>
                    <div class="container custom-container-slide">
                        <div class="slide-description">
			    <p style='font-weight: bold; font-size: 26px;'>~~Website is Under Construction~~</p>
                            <h2 class="title">A Trustworthy Team</h2>

                            <p>Experienced Management<br />Professional Engineers <br />& Skilled Construction Group</p>
                           <!-- <a class="slide-link" href="#"> EXPLORE MORE </a> <!-- Can we delete the EXPLORE MORE Button? -->

                        </div>
                    </div>
                </li>

            </ul>
        </div>
    </div>
</div>
<!--home slider ends-->

<!--about section-->
<section id="about" class="about-us section variant-four">

    <div class="container wow fadeInUp animated">


        <h2 class="section-intro-text"><span>about us</span></h2>

        <header class="section-header">

          <!--  <h2 class="title">7 YEARS IN BUSINESS <br> WOW!</h2> -->

<p>Aegis is a disabled-veteran owned and operated mechanical contractor performing HVAC and plumbing construction in Maryland-Washington area, focused on providing comprehensive mechanical solutions for commercial and government clients.</p>
            <!-- <p>some more shit about us... maybe even refrences: <a href="#">here</a> or <a
                    href="#">there</a>,
                <br> We just want you to know its all good !
            </p>-->

        </header>

        <div class="row">

            <div data-wow-delay="200ms" class="innards wow fadeIn  col-sm-4 animated">

                <span class="line-vertical"></span>

                <figure>

                    <img alt="" src="images/temp/about-image-4.png">

                </figure>

                <h3 class="title">Schedule</h3>

                <p>
                    Meeting fast-track schedules
                </p>

            </div>

            <div data-wow-delay="400ms" class="innards wow fadeIn  col-sm-4 animated">

                <span class="line-vertical"></span>

                <figure>

                    <img alt="" src="images/temp/about-image-5.png">

                </figure>


                <h3 class="title">Scope & Quality</h3>

                <p>
                    Operating with Class-A quality control
                </p>

            </div>

            <div data-wow-delay="600ms" class="innards wow fadeIn  col-sm-4 animated">

                <span class="line-vertical"></span>

                <figure>

                    <img alt="" src="images/temp/about-image-6.png">

                </figure>


                <h3 class="title">Customer Satisfaction</h3>

                <p>
                    Our one and only goal
                </p>


            </div>

        </div>


    </div>

</section>
<!--about section ends-->

<!--features-->
<section id="featues" class="features variant-four  section">

    <div class="container wow fadeInUp animated" style="padding-bottom: 30px;">

        <h2 class="section-intro-text"><span>We can be trusted.</span></h2>

<header class="section-header" style="margin-bottom: 20px;">
            <h3 class="title">Certifications</h2>
</header>

        <div class="row column">
        <div class="col-sm-4 col-sm-offset-4">
                    <div class="list-arrow-bullet">
                        <ul>
                            <li style="font-size: 17px;">MDOT MBE/DBE</li>
                            <li style="font-size: 17px;">Baltimore City MWBOO MBE Certified</li>
                            <li style="font-size: 17px;">Baltimore City LBE</li>
                            <li style="font-size: 17px;">Service Disabled Owned Business (CVE Approved)</li>
                            <li style="font-size: 17px;">Prince Georges County SDDD Certified</li>

                        </ul>
                    </div>
                </div>
        </div>

    </div>

</section>
<!--features ends-->

<!--clients carousel-->
<section id="clients" class="our-clients variant-four  section">

    <div class="container wow fadeInUp">

        <header class="section-header">

            <h3 class="title">Clients</h3>

            <p>Clients and General Contractors that we have served in the past</p>

        </header>

        <div class="client-section-carousel">
            <div id="owl-carousel-4" class="client-carousel owl-theme">
                <div class="item">Turner Construction</div>
                <div class="item">Whiting-Turner</div>
                <div class="item">Jeffrey Brown Contracting</div>
                <div class="item">Plano-Coudon</div>
                <div class="item">Commercial Construction</div>
                <div class="item">Clarks</div>
                <div class="item">DPR</div>
                <div class="item">F.H. Paschen</div>
                <div class="item">HITT Contracting</div>
            </div>
        </div>

    </div>

</section>

<!--clients carousel ends-->

<!--services carousel-->
<section id="projects" class="our-services variant-four  section">

    <div class="container wow fadeInUp">

        <header class="section-header">

            <h2 class="title">how aegis works</h2>

            <p>
                <!--Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer feugiat dolor nibh. Cum sociis natoque
                penatibus et magnis dis <br> parturient montes-->
            </p>

        </header>

        <div class="services-section-carousel">

            <a class="prev"></a>
            <a class="next"></a>

            <div id="owl-carousel">
                <a class="item" href="#">
                    <div class="icon-container">
                        <i class="fa fa-lightbulb-o fa-3x"></i>
                    </div>
                    <div class="contents">
                        <h5>Detailed Scope Review</h5>
                    </div>
                </a>
                <a href="#" class="item">
                    <div class="icon-container">
                        <i class="fa fa-desktop fa-3x"></i>
                    </div>
                    <div class="contents">
                        <h5>High & Low Level Scheduling</h5>
                    </div>
                </a>

                <a href="#" class="item">
                    <div class="icon-container">
                        <i class="fa fa-pencil fa-3x"></i>
                    </div>
                    <div class="contents">
                        <h5>Design Verification</h5>
                    </div>
                </a>

                <a href="#" class="item">
                    <div class="icon-container">
                        <i class="fa fa-flask fa-3x"></i>
                    </div>
                    <div class="contents">
                        <h5>Quality Control</h5>
                    </div>
                </a>

                <a href="#" class="item">
                    <div class="icon-container">
                        <i class="fa fa-cog fa-3x"></i>
                    </div>
                    <div class="contents">
                        <h5>Service & Maintenance</h5>
                    </div>
                </a>

               <!-- <a class="item" href="#">
                    <div class="icon-container">
                        <i class="fa fa-globe fa-3x"></i>
                    </div>
                    <div class="contents">
                        <h5>creative design</h5>
                    </div>
                </a>-->

            </div>

        </div>

    </div>

</section>


<!--services carousel ends-->

<!--services list-->
<section id="services-list" class="our-work variant-four  section" style="background-color: #f0eeed;">

<div class="container container-work-4">

<header class="section-header">
   <h2 class="title">Projects</h2>
   <p>Here are a selection of the projects that our team at Aegis our currently working on
   </p>
</header>

<section class="projects-showcase container">
   <div class="top-arrow"></div>
   <div class="portfolio-response">
       <div class="row">
           <div class="slide-show col-lg-8 col-md-7">
               <div class="flexslider custom-margin-slider">
                   <ul class="slides">
                       <li><img src="images/temp/pr/1.jpg" alt=""/></li>
                       <li><img src="images/temp/pr/2.jpg" alt=""/></li>
                       <li><img src="images/temp/pr/3.jpg" alt=""/></li>
                       <li><img src="images/temp/pr/4.jpg" alt=""/></li>
                       <li><img src="images/temp/pr/5.jpg" alt=""/></li>
                       <li><img src="images/temp/pr/6.jpg" alt=""/></li>
                       <li><img src="images/temp/pr/7.jpg" alt=""/></li>
                   </ul>
               </div>
           </div>
           <div class="project-details col-lg-4 col-md-5">
               <article class="work-4-detail clearfix">
                   <h1 class="title">Current Projects</h1>

                   <div class="work-one">
                       <ul>
                           <li>Greyhound Intermodal Terminal</li>
                           <li>Exelon Building</li>
                           <li>CC Jackson Recreation Center</li>
                           <li>Baltimore County Board Of Elections</li>
                           <li>Maryland Automobile Insurance Fund Headquarters</li>
                           <li>BGE Executive Office</li>
                           <li>Towson University Fine Arts Building</li>
                           <li>Towson University Glen Towers</li>
                           <li>Coppin State University – Daley Hall</li>
                       </ul>
                   </div>
               </article>
           </div>
       </div>
   </div>
</section>
</div>

</section>
<!--services list ends-->

<!--our work section-->
<section id="work" class="our-work variant-four wow fadeInUp section">

<div class="container container-work-4">

<header class="section-header">

    <h2 class="title">Portfolio</h2>

   <!-- <p>We done some good shiiit.
    </p>-->

</header>


<section class="container" style="padding-bottom:25px;">

        <div class="row column">
        	<div class="col-sm-6 col-sm-offset-3">
	                <ul class="faqs-wrap clearfix">
	                    <li class="group faq-category">
	                        <h3 class="faq-title"><span></span>Hospital & HealthCare Facilities</h3>
	                        <div class="faq-body">
		                    <div class="list-arrow-bullet">
		                        <ul style="margin: 18px 0 14px 2px;">
		                            <li>Johns Hopkins Hospital</li>
		                            <li>Mercy Medical Center</li>
		                            <li>Ann Arundel Medical Center</li>
		                            <li>Bayview Medical Center</li>
		                            <li>Bon Secours Center</li>
		                        </ul>
		                    </div>
	                        </div>
	                    </li>

	                    <li class="group faq-category">
	                        <h3 class="faq-title"><span></span>Science & Technology Facilities</h3>
	                        <div class="faq-body">
		                    <div class="list-arrow-bullet">
		                        <ul style="margin: 18px 0 14px 2px;">
		                            <li>Maryland Public Health Labs (BSL-3)</li>
		                            <li>Rangos Building on North Wolfe St. Baltimore</li>
		                        </ul>
		                    </div>
	                        </div>
	                    </li>
	                    <li class="group faq-category">
	                        <h3 class="faq-title"><span></span>Schools & Higher Education</h3>
	                        <div class="faq-body">
		                    <div class="list-arrow-bullet">
		                        <ul style="margin: 18px 0 14px 2px;">
		                            <li>Johns Hopkins University – Homewood Campus</li>
		                            <li>University of Maryland – Baltimore</li>
		                            <li>University of Baltimore</li>
		                            <li>University of Maryland – Baltimore County</li>
		                            <li>University of Maryland – College Park</li>
		                        </ul>
		                    </div>
	                        </div>
	                    </li>
	                    <li class="group faq-category">
	                        <h3 class="faq-title"><span></span>Office Buildings</h3>
	                        <div class="faq-body">
		                    <div class="list-arrow-bullet">
		                        <ul style="margin: 18px 0 14px 2px;">
		                            <li>T Rowe Price Buildings 5 & 6</li>
		                            <li>OmniCare</li>
		                            <li>Tydings & Rosenberg</li>
		                            <li>Maryland Lottery</li>
		                        </ul>
		                    </div>
	                        </div>
	                    </li>
	                    <li class="group faq-category">
	                        <h3 class="faq-title"><span></span>Military Installations/Government Facilities</h3>
	                        <div class="faq-body">
		                    <div class="list-arrow-bullet">
		                        <ul style="margin: 18px 0 14px 2px;">
		                            <li>Andrews AirForce Base</li>
		                            <li>BGE Stations – Tipton & Russett</li>
		                            <li>Cecil County Courthouse</li>
		                            <li>Baltimore County Executive’s Office</li>
		                        </ul>
		                    </div>
	                        </div>
	                    </li>
	                    <li class="group faq-category">
	                        <h3 class="faq-title"><span></span>Historical Buildings</h3>
	                        <div class="faq-body">
		                    <div class="list-arrow-bullet">
		                        <ul style="margin: 18px 0 14px 2px;">
		                            <li>Clifton Mansion Restorations</li>
		                            <li>The Center for Parks & People</li>
		                        </ul>
		                    </div>
	                        </div>
	                    </li>
	               </ul>
                </div>
        </div>


</section>
<!--
<div class="separator">
                    <span class="line"></span><span class="square"></span><span class="line"></span>
                </div>

-->


<!-- Gallery Filter
<div id="filter-by" class="clearfix">
    <a href="#" data-filter="web-design" class="active filter-btn">Government</a>
    <a href="#" data-filter="print-media" class="filter-btn">Historic</a>
    <a href="#" data-filter="application-development" class="filter-btn">Hospital & HealthCare</a>
    <a href="#" data-filter="wordpress-themes" class="filter-btn">Office Buildings</a>
    <a href="#" data-filter="web-development" class="filter-btn">School</a>
    <a href="#" data-filter="web-developments" class="filter-btn">Science & Tech</a>
</div>


<div id="gallery-container">

    <div class="row gallery-4-columns isotope clearfix">

        <div class="gallery-item isotope-item web-design print-media wordpress-themes col-lg-3 col-sm-4 col-xs-6">

            <div class="inner-contents">
                <div class="media-container">
                    <h5 class="item-title"><a href="#" title="">Illustration with pencil work</a></h5>

                    <p>Graphic Design</p>
                    <a class="gallery-btn" href="#" title="">EXPLORE MORE</a>
                </div>
                <div class="overlay"></div>
                <figure>
                    <img src="images/temp/gallery-image-1.jpg" alt="Photo">
                </figure>
            </div>
        </div>

        <div class="gallery-item isotope-item web-design web-development col-lg-3 col-sm-4 col-xs-6">

            <div class="inner-contents">
                <div class="media-container">
                    <h5 class="item-title"><a href="#" title="">3D type animation work</a></h5>

                    <p>Multimedia Solution</p>
                    <a class="gallery-btn" href="#" title="">EXPLORE MORE</a>
                </div>
                <div class="overlay"></div>
                <figure>
                    <img src="images/temp/gallery-image-2.jpg" alt="Photo">
                </figure>
            </div>
        </div>


        <div class="gallery-item isotope-item application-development col-lg-3 col-sm-4 col-xs-6">

            <div class="inner-contents">
                <div class="media-container">
                    <h5 class="item-title"><a href="#" title="">Awesome Website Design</a></h5>

                    <p>Web Design</p>
                    <a class="gallery-btn" href="#" title="">EXPLORE MORE</a>
                </div>
                <div class="overlay"></div>
                <figure>
                    <img src="images/temp/gallery-image-3.jpg" alt="Photo">
                </figure>
            </div>

        </div>

        <div class="gallery-item isotope-item web-design print-media col-lg-3 col-sm-4 col-xs-6">

            <div class="inner-contents">
                <div class="media-container">
                    <h5 class="item-title"><a href="#" title="">Creative Bulb with fresh mind</a></h5>

                    <p>Graphic Design</p>
                    <a class="gallery-btn" href="#" title="">EXPLORE MORE</a>
                </div>
                <div class="overlay"></div>
                <figure>
                    <img src="images/temp/gallery-image-4.jpg" alt="Photo">
                </figure>
            </div>

        </div>


        <div class="gallery-item isotope-item print-media col-lg-3 col-sm-4 col-xs-6">

            <div class="inner-contents">
                <div class="media-container">
                    <h5 class="item-title"><a href="#" title="">World globe with properties</a></h5>

                    <p>Print Media Solution</p>
                    <a class="gallery-btn" href="#" title="">EXPLORE MORE</a>
                </div>
                <div class="overlay"></div>
                <figure>
                    <img src="images/temp/gallery-image-5.jpg" alt="Photo">
                </figure>
            </div>

        </div>

        <div class="gallery-item isotope-item wordpress-themes col-lg-3 col-sm-4 col-xs-6">

            <div class="inner-contents">
                <div class="media-container">
                    <h5 class="item-title"><a href="#" title="">Creative Photoshop</a></h5>

                    <p>Web Design</p>
                    <a class="gallery-btn" href="#" title="">EXPLORE MORE</a>
                </div>
                <div class="overlay"></div>
                <figure>
                    <img src="images/temp/gallery-image-6.jpg" alt="Photo">
                </figure>
            </div>

        </div>

        <div class="gallery-item isotope-item web-design  col-lg-3 col-sm-4 col-xs-6">
            <div class="inner-contents">
                <div class="media-container">
                    <h5 class="item-title"><a href="#" title="">Cold Cofee with Cookies</a></h5>

                    <p>Wordpress Theme</p>
                    <a class="gallery-btn" href="#" title="">EXPLORE MORE</a>
                </div>
                <div class="overlay"></div>
                <figure>
                    <img src="images/temp/gallery-image-7.jpg" alt="Photo">
                </figure>
            </div>

        </div>


        <div class="gallery-item isotope-item web-design wordpress-themes col-lg-3 col-sm-4 col-xs-6">
            <div class="inner-contents">
                <div class="media-container">
                    <h5 class="item-title"><a href="#" title="">Great App for iPhone</a></h5>

                    <p>Application</p>
                    <a class="gallery-btn" href="#" title="">EXPLORE MORE</a>
                </div>
                <div class="overlay"></div>
                <figure>
                    <img src="images/temp/gallery-image-8.jpg" alt="Photo">
                </figure>
            </div>

        </div>

    </div>

</div>

</div>

    <div class="section-surf arrow ">
        <div class="shape"></div>
        <div class="icon"></div>
    </div>

</section>
<!--our work section ends-->

<!--follow us slider-->
<section id="careers" class="follow-us variant-four section">

    <div class="flexslider">

        <div class="container">

            <header class="section-header">

                <h2 class="title">Careers</h2>

            </header>

        </div>

        <ul class="widget widget_displaytweetswidget clearfix">
            <li>
                <div class="container custom-container-follow">

                    <div class="icon-container">
                        <i class="icon-twitter fa fa-download"></i>
                    </div>

                    <p>
                        Our team can always use new talented hires! Send your resume to <a href="mailto:info@aegismechanical.com">info@aegismechanical.com</a> <br />
            </li>
        </ul>
    </div>

</section>
<!--follow us slider ends-->

<section id="contact-details" class="contact-details  section">

    <div class="inner-wrapper">

        <div class="contact-details-container wow fadeInUp">

            <div class="icon-container">
                <i class="icon-pin"></i>
            </div>

            <header class="section-header">
                <h2 class="title">AEGIS MECHANICAL</h2>

                <div class="separator">
                    <span class="line"></span>
                    <span class="square"></span>
                    <span class="line"></span>
                </div>
                <p>2056 Lord Baltimore Dr. Baltimore, MD 21244</p>
            </header>

            <ul class="contact-details-list clearfix">
                <li class="phone-number">
                    <i class="icon-telephone"></i>
                    443-436-6001
                </li>
                <li class="fax">
                    <i class="icon-fax"></i>
                    443-436-6002
                </li>
                <li class="email">
                    <i class="icon-mail"></i>
                    <a href="mailto:info@aegismech.com">info@aegismech.com</a>
                </li>
            </ul>

        </div>

        <div class="google-map-wrapper">
            <div id="map_canvas"></div>
            <script type="text/javascript" src="http://maps.google.com/maps/api/js?v=3&amp;sensor=false"></script>
            <script type="text/javascript">
                function init_map() {

                    var mapLatitude = 39.305219,
                            mapLongitude = -76.752818,
                            mapZoom = 14;

                    var myOptions = {
                        zoom: mapZoom,
                        scrollwheel: false,
                        disableDefaultUI: true,
                        center: new google.maps.LatLng(mapLatitude, mapLongitude),
                        mapTypeId: google.maps.MapTypeId.ROADMAP,
                        styles: [
                            {
                                "featureType": "landscape",
                                "elementType": "labels",
                                "stylers": [
                                    {
                                        "visibility": "off"
                                    }
                                ]
                            },
                            {
                                "featureType": "transit",
                                "elementType": "labels",
                                "stylers": [
                                    {
                                        "visibility": "off"
                                    }
                                ]
                            },
                            {
                                "featureType": "poi",
                                "elementType": "labels",
                                "stylers": [
                                    {
                                        "visibility": "off"
                                    }
                                ]
                            },
                            {
                                "featureType": "water",
                                "elementType": "labels",
                                "stylers": [
                                    {
                                        "visibility": "off"
                                    }
                                ]
                            },
                            {
                                "featureType": "road",
                                "elementType": "labels.icon",
                                "stylers": [
                                    {
                                        "visibility": "off"
                                    }
                                ]
                            },
                            {
                                "stylers": [
                                    {
                                        "hue": "#00aaff"
                                    },
                                    {
                                        "saturation": -100
                                    },
                                    {
                                        "gamma": 2.15
                                    },
                                    {
                                        "lightness": 12
                                    }
                                ]
                            },
                            {
                                "featureType": "road",
                                "elementType": "labels.text.fill",
                                "stylers": [
                                    {
                                        "visibility": "on"
                                    },
                                    {
                                        "lightness": 24
                                    }
                                ]
                            },
                            {
                                "featureType": "road",
                                "elementType": "geometry",
                                "stylers": [
                                    {
                                        "lightness": 57
                                    }
                                ]
                            }
                        ]
                    };
                    map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
                }
                google.maps.event.addDomListener(window, "load", init_map);
            </script>

        </div>

    </div>

</section>
<!--contact detail end-->


<!--contact form-->
<section id="contact" class="contact-us section ">

    <div class="container wow fadeInUp animated">

        <!-- Section Title  -->
        <header class="section-header">
            <h2 class="title">GET IN TOUCH</h2>

            <div class="separator">
                <span class="line"></span><span class="square"></span><span class="line"></span>
            </div>
            <p>Fill up the below form and we will get back to you within 24 hours</p>
        </header>
        <form class="contact-form wow fadeInUp animated" method="post" action="functions.php" novalidate="novalidate">

            <p>
                <input type="text" name="name" id="name" class="required" placeholder="Name"
                       title="*Please enter your name">
                <input type="text" name="email" id="email" class="email required" placeholder="Email Address"
                       title="*Please enter your email address">
            </p>

            <p>
                <input type="text" name="subject" id="subject" placeholder="Subject">
            </p>

            <p>
                <textarea name="message" id="comment" class="required" placeholder="Message"
                          title="*Please enter your message"></textarea>
            </p>

            <div class="clearfix">

                <div class="status-wrapper">
                    <div class="error-container"></div>
                    <div id="message-sent"></div>
                </div>

                <div class="submit-and-loader">
                    <input type="submit" value="Submit Now" id="submit" name="submit">
                    <img src="images/ajax-loader-3.gif" id="contact-loader" alt="Loading...">
                </div>

            </div>

        </form>


    </div>

</section>
<!--contact form end-->


<script src="js/bootstrap.min.js"></script>

<script src="js/jquery.easing.1.3.js"></script>

<script src="js/flexslider/jquery.flexslider-min.js"></script>

<script src="js/jquery.parallax-1.1.3.js"></script>

<script src="js/jquery.velocity.min.js"></script>

<script src="js/jquery.transit.min.js"></script>

<script src="js/wow.min.js"></script>

<script src="js/owl-carousel/owl.carousel.min.js"></script>

<script src="js/adipoli/jquery.adipoli.min.js"></script>

<script src="js/swipebox/jquery.swipebox.js"></script>

<script src="js/responsive-nav.min.js"></script>

<script src="js/mean-menu/jquery.meanmenu.min.js"></script>

<script src="js/jquery.isotope.min.js"></script>

<script src="js/jquery.validate.min.js"></script>

<script src="js/jquery.form.js"></script>


<script src="js/twitter-fetcher.js"></script>

<script src="js/custom.js"></script>


</body>

</html>
